package mk.ukim.finki.lab.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import mk.ukim.finki.lab.model.Album;

@Repository
public class AlbumRepository {
    private final List<Album> albums;

    public AlbumRepository() {
        this.albums = List.of(
                new Album("After Hours", "R&B", "2020"),
                new Album("The Tortured Poets Department", "Synth-pop", "2024"),
                new Album("Short n' Sweet", "Pop", "2024"),
                new Album("Hit me hard and soft", "bedroom pop", "2024"),
                new Album("Eternal sunshine", "Pop", "2024"));
    }

    public List<Album> findAll() {
        return albums;
    }

    public Optional<Album> findById(Long id) {
        return albums.stream().filter(album -> album.getId().equals(id)).findAny();
    }

}
