package mk.ukim.finki.lab.repository;

import org.springframework.stereotype.Repository;

import mk.ukim.finki.lab.model.Artist;

import java.util.List;
import java.util.Optional;

@Repository
public class ArtistRepository {
    private final List<Artist> artists;

    public ArtistRepository() {
        this.artists = List.of(
                new Artist("Meliha", "Jusufovikj", "The one in love"),
                new Artist("Jasna", "Jovanova", "Always hungry"),
                new Artist("Gamze", "Mustafa", "Has an orange cat"),
                new Artist("Mila", "Kirovski", "Mysterious friend"),
                new Artist("Marija", "Josheska", "joshi"));
    }

    public List<Artist> findAll() {
        return artists;
    }

    public Optional<Artist> findById(Long id) {
        for (Artist artist : artists) {
            if (artist.getId().equals(id)) {
                return Optional.of(artist);
            }
        }
        return Optional.empty();
    }

}
