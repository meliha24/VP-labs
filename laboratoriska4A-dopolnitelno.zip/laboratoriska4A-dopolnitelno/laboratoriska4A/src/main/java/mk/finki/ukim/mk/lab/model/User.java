package mk.finki.ukim.mk.lab.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.Collection;
import java.util.Collections;
import lombok.Generated;
import mk.finki.ukim.mk.lab.model.enumaration.Role;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
@Table(
        name = "shop_users"
)
public class User implements UserDetails {
    @Id
    private String username;
    private String password;
    private String name;
    private String surname;
    private boolean isAccountNonExpired = true;
    private boolean isAccountNonLocked = true;
    private boolean isCredentialsNonExpired = true;
    private boolean isEnabled = true;
    private Role role;

    public User(String username, String password, String name, String surname, Role role) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.role = role;
    }

    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singletonList(this.role);
    }

    public boolean isAccountNonExpired() {
        return this.isAccountNonExpired;
    }

    public boolean isAccountNonLocked() {
        return this.isAccountNonLocked;
    }

    public boolean isCredentialsNonExpired() {
        return this.isCredentialsNonExpired;
    }

    public boolean isEnabled() {
        return this.isEnabled;
    }

    @Generated
    public String getUsername() {
        return this.username;
    }

    @Generated
    public String getPassword() {
        return this.password;
    }

    @Generated
    public String getName() {
        return this.name;
    }

    @Generated
    public String getSurname() {
        return this.surname;
    }

    @Generated
    public Role getRole() {
        return this.role;
    }

    @Generated
    public void setUsername(final String username) {
        this.username = username;
    }

    @Generated
    public void setPassword(final String password) {
        this.password = password;
    }

    @Generated
    public void setName(final String name) {
        this.name = name;
    }

    @Generated
    public void setSurname(final String surname) {
        this.surname = surname;
    }

    @Generated
    public void setAccountNonExpired(final boolean isAccountNonExpired) {
        this.isAccountNonExpired = isAccountNonExpired;
    }

    @Generated
    public void setAccountNonLocked(final boolean isAccountNonLocked) {
        this.isAccountNonLocked = isAccountNonLocked;
    }

    @Generated
    public void setCredentialsNonExpired(final boolean isCredentialsNonExpired) {
        this.isCredentialsNonExpired = isCredentialsNonExpired;
    }

    @Generated
    public void setEnabled(final boolean isEnabled) {
        this.isEnabled = isEnabled;
    }

    @Generated
    public void setRole(final Role role) {
        this.role = role;
    }

    @Generated
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof User)) {
            return false;
        } else {
            User other = (User)o;
            if (!other.canEqual(this)) {
                return false;
            } else if (this.isAccountNonExpired() != other.isAccountNonExpired()) {
                return false;
            } else if (this.isAccountNonLocked() != other.isAccountNonLocked()) {
                return false;
            } else if (this.isCredentialsNonExpired() != other.isCredentialsNonExpired()) {
                return false;
            } else if (this.isEnabled() != other.isEnabled()) {
                return false;
            } else {
                Object this$username = this.getUsername();
                Object other$username = other.getUsername();
                if (this$username == null) {
                    if (other$username != null) {
                        return false;
                    }
                } else if (!this$username.equals(other$username)) {
                    return false;
                }

                label74: {
                    Object this$password = this.getPassword();
                    Object other$password = other.getPassword();
                    if (this$password == null) {
                        if (other$password == null) {
                            break label74;
                        }
                    } else if (this$password.equals(other$password)) {
                        break label74;
                    }

                    return false;
                }

                label67: {
                    Object this$name = this.getName();
                    Object other$name = other.getName();
                    if (this$name == null) {
                        if (other$name == null) {
                            break label67;
                        }
                    } else if (this$name.equals(other$name)) {
                        break label67;
                    }

                    return false;
                }

                Object this$surname = this.getSurname();
                Object other$surname = other.getSurname();
                if (this$surname == null) {
                    if (other$surname != null) {
                        return false;
                    }
                } else if (!this$surname.equals(other$surname)) {
                    return false;
                }

                Object this$role = this;
                Object other$role = other;
                if (this$role == null) {
                    if (other$role != null) {
                        return false;
                    }
                } else if (!this$role.equals(other$role)) {
                    return false;
                }

                return true;
            }
        }
    }

    @Generated
    protected boolean canEqual(final Object other) {
        return other instanceof User;
    }

    @Generated
    public int hashCode() {
        boolean PRIME = true;
        int result = 1;
        result = result * 59 + (this.isAccountNonExpired() ? 79 : 97);
        result = result * 59 + (this.isAccountNonLocked() ? 79 : 97);
        result = result * 59 + (this.isCredentialsNonExpired() ? 79 : 97);
        result = result * 59 + (this.isEnabled() ? 79 : 97);
        Object $username = this.getUsername();
        result = result * 59 + ($username == null ? 43 : $username.hashCode());
        Object $password = this.getPassword();
        result = result * 59 + ($password == null ? 43 : $password.hashCode());
        Object $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        Object $surname = this.getSurname();
        result = result * 59 + ($surname == null ? 43 : $surname.hashCode());
        Object $role = this;
        result = result * 59 + ($role == null ? 43 : $role.hashCode());
        return result;
    }

    @Generated
    public String toString() {
        String var10000 = this.getUsername();
        return "User(username=" + var10000 + ", password=" + this.getPassword() + ", name=" + this.getName() + ", surname=" + this.getSurname() + ", isAccountNonExpired=" + this.isAccountNonExpired() + ", isAccountNonLocked=" + this.isAccountNonLocked() + ", isCredentialsNonExpired=" + this.isCredentialsNonExpired() + ", isEnabled=" + this.isEnabled() + ", role=" + String.valueOf(this.getRole()) + ")";
    }

    @Generated
    public User() {
    }
}

